import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  BannerCarousel: () => import('../..\\components\\BannerCarousel.vue' /* webpackChunkName: "components/banner-carousel" */).then(c => wrapFunctional(c.default || c)),
  Footer: () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c)),
  Keunggulan: () => import('../..\\components\\Keunggulan.vue' /* webpackChunkName: "components/keunggulan" */).then(c => wrapFunctional(c.default || c)),
  MitraBimGuru: () => import('../..\\components\\MitraBimGuru.vue' /* webpackChunkName: "components/mitra-bim-guru" */).then(c => wrapFunctional(c.default || c)),
  ModalKontak: () => import('../..\\components\\ModalKontak.vue' /* webpackChunkName: "components/modal-kontak" */).then(c => wrapFunctional(c.default || c)),
  ModalProduct: () => import('../..\\components\\ModalProduct.vue' /* webpackChunkName: "components/modal-product" */).then(c => wrapFunctional(c.default || c)),
  NavBar: () => import('../..\\components\\NavBar.vue' /* webpackChunkName: "components/nav-bar" */).then(c => wrapFunctional(c.default || c)),
  Products: () => import('../..\\components\\Products.vue' /* webpackChunkName: "components/products" */).then(c => wrapFunctional(c.default || c)),
  ProfilBar: () => import('../..\\components\\ProfilBar.vue' /* webpackChunkName: "components/profil-bar" */).then(c => wrapFunctional(c.default || c)),
  Reviews: () => import('../..\\components\\Reviews.vue' /* webpackChunkName: "components/reviews" */).then(c => wrapFunctional(c.default || c)),
  TitleBar: () => import('../..\\components\\TitleBar.vue' /* webpackChunkName: "components/title-bar" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
