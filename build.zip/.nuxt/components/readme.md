# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<BannerCarousel>` | `<banner-carousel>` (components/BannerCarousel.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Keunggulan>` | `<keunggulan>` (components/Keunggulan.vue)
- `<MitraBimGuru>` | `<mitra-bim-guru>` (components/MitraBimGuru.vue)
- `<ModalKontak>` | `<modal-kontak>` (components/ModalKontak.vue)
- `<ModalProduct>` | `<modal-product>` (components/ModalProduct.vue)
- `<NavBar>` | `<nav-bar>` (components/NavBar.vue)
- `<Products>` | `<products>` (components/Products.vue)
- `<ProfilBar>` | `<profil-bar>` (components/ProfilBar.vue)
- `<Reviews>` | `<reviews>` (components/Reviews.vue)
- `<TitleBar>` | `<title-bar>` (components/TitleBar.vue)
