import { wrapFunctional } from './utils'

export { default as BannerCarousel } from '../..\\components\\BannerCarousel.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Keunggulan } from '../..\\components\\Keunggulan.vue'
export { default as MitraBimGuru } from '../..\\components\\MitraBimGuru.vue'
export { default as ModalKontak } from '../..\\components\\ModalKontak.vue'
export { default as ModalProduct } from '../..\\components\\ModalProduct.vue'
export { default as NavBar } from '../..\\components\\NavBar.vue'
export { default as Products } from '../..\\components\\Products.vue'
export { default as ProfilBar } from '../..\\components\\ProfilBar.vue'
export { default as Reviews } from '../..\\components\\Reviews.vue'
export { default as TitleBar } from '../..\\components\\TitleBar.vue'

export const LazyBannerCarousel = import('../..\\components\\BannerCarousel.vue' /* webpackChunkName: "components/banner-carousel" */).then(c => wrapFunctional(c.default || c))
export const LazyFooter = import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const LazyKeunggulan = import('../..\\components\\Keunggulan.vue' /* webpackChunkName: "components/keunggulan" */).then(c => wrapFunctional(c.default || c))
export const LazyMitraBimGuru = import('../..\\components\\MitraBimGuru.vue' /* webpackChunkName: "components/mitra-bim-guru" */).then(c => wrapFunctional(c.default || c))
export const LazyModalKontak = import('../..\\components\\ModalKontak.vue' /* webpackChunkName: "components/modal-kontak" */).then(c => wrapFunctional(c.default || c))
export const LazyModalProduct = import('../..\\components\\ModalProduct.vue' /* webpackChunkName: "components/modal-product" */).then(c => wrapFunctional(c.default || c))
export const LazyNavBar = import('../..\\components\\NavBar.vue' /* webpackChunkName: "components/nav-bar" */).then(c => wrapFunctional(c.default || c))
export const LazyProducts = import('../..\\components\\Products.vue' /* webpackChunkName: "components/products" */).then(c => wrapFunctional(c.default || c))
export const LazyProfilBar = import('../..\\components\\ProfilBar.vue' /* webpackChunkName: "components/profil-bar" */).then(c => wrapFunctional(c.default || c))
export const LazyReviews = import('../..\\components\\Reviews.vue' /* webpackChunkName: "components/reviews" */).then(c => wrapFunctional(c.default || c))
export const LazyTitleBar = import('../..\\components\\TitleBar.vue' /* webpackChunkName: "components/title-bar" */).then(c => wrapFunctional(c.default || c))
