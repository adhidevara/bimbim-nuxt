import Vue from 'vue'
import TvButton from 'tv-button'
import 'tv-button/dist/tv-button.css'
Vue.use(TvButton)
