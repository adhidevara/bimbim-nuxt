import Vue from 'vue'
import Vuex from 'vuex'
import Meta from 'vue-meta'
import ClientOnly from 'vue-client-only'
import NoSsr from 'vue-no-ssr'
import { createRouter } from './router.js'
import NuxtChild from './components/nuxt-child.js'
import NuxtError from './components/nuxt-error.vue'
import Nuxt from './components/nuxt.js'
import App from './App.js'
import { setContext, getLocation, getRouteData, normalizeError } from './utils'
import { createStore } from './store.js'

/* Plugins */

import nuxt_plugin_plugin_3a98660e from 'nuxt_plugin_plugin_3a98660e' // Source: .\\components\\plugin.js (mode: 'all')
import nuxt_plugin_templatesplugin8477430c_1e1c3d44 from 'nuxt_plugin_templatesplugin8477430c_1e1c3d44' // Source: .\\templates.plugin.8477430c.js (mode: 'all')
import nuxt_plugin_toastclient_36975a0a from 'nuxt_plugin_toastclient_36975a0a' // Source: .\\toast.client.js (mode: 'client')
import nuxt_plugin_button_41332c0a from 'nuxt_plugin_button_41332c0a' // Source: .\\button.js (mode: 'all')
import nuxt_plugin_helper_e3aabbe4 from 'nuxt_plugin_helper_e3aabbe4' // Source: .\\helper.js (mode: 'all')
import nuxt_plugin_icon_26efcaba from 'nuxt_plugin_icon_26efcaba' // Source: .\\icon.js (mode: 'all')
import nuxt_plugin_vlazyload_5cbc32ec from 'nuxt_plugin_vlazyload_5cbc32ec' // Source: .\\v-lazy-load.js (mode: 'all')
import nuxt_plugin_clipboard_b96f3808 from 'nuxt_plugin_clipboard_b96f3808' // Source: .\\clipboard.js (mode: 'client')
import nuxt_plugin_pluginclient_2104092f from 'nuxt_plugin_pluginclient_2104092f' // Source: .\\content\\plugin.client.js (mode: 'client')
import nuxt_plugin_pluginserver_f2850a92 from 'nuxt_plugin_pluginserver_f2850a92' // Source: .\\content\\plugin.server.js (mode: 'server')
import nuxt_plugin_workbox_98792690 from 'nuxt_plugin_workbox_98792690' // Source: .\\workbox.js (mode: 'client')
import nuxt_plugin_metaplugin_3db22938 from 'nuxt_plugin_metaplugin_3db22938' // Source: .\\pwa\\meta.plugin.js (mode: 'all')
import nuxt_plugin_iconplugin_4259ceac from 'nuxt_plugin_iconplugin_4259ceac' // Source: .\\pwa\\icon.plugin.js (mode: 'all')
import nuxt_plugin_axios_9b77a2c8 from 'nuxt_plugin_axios_9b77a2c8' // Source: .\\axios.js (mode: 'all')
import nuxt_plugin_vueslickcarousel_d8b69d56 from 'nuxt_plugin_vueslickcarousel_d8b69d56' // Source: ..\\plugins\\vue-slick-carousel.js (mode: 'all')
import nuxt_plugin_veevalidate_81ef739a from 'nuxt_plugin_veevalidate_81ef739a' // Source: ..\\plugins\\vee-validate (mode: 'all')
import nuxt_plugin_vueselect_d190152e from 'nuxt_plugin_vueselect_d190152e' // Source: ..\\plugins\\vue-select (mode: 'all')
import nuxt_plugin_vuejsmodal_9e1ca9ae from 'nuxt_plugin_vuejsmodal_9e1ca9ae' // Source: ..\\plugins\\vuejs-modal (mode: 'all')
import nuxt_plugin_vuesocialsharing_504631e9 from 'nuxt_plugin_vuesocialsharing_504631e9' // Source: ..\\plugins\\vue-social-sharing (mode: 'all')
import nuxt_plugin_vueobservevisibility_c32a0d60 from 'nuxt_plugin_vueobservevisibility_c32a0d60' // Source: ..\\plugins\\vue-observe-visibility (mode: 'all')
import nuxt_plugin_vuedatetimepicker_4d605153 from 'nuxt_plugin_vuedatetimepicker_4d605153' // Source: ..\\plugins\\vue-datetime-picker (mode: 'all')
import nuxt_plugin_vueformwizard_9fcc0b72 from 'nuxt_plugin_vueformwizard_9fcc0b72' // Source: ..\\plugins\\vue-form-wizard (mode: 'all')
import nuxt_plugin_vueyoutubeembed_08ecc2a2 from 'nuxt_plugin_vueyoutubeembed_08ecc2a2' // Source: ..\\plugins\\vue-youtube-embed (mode: 'client')
import nuxt_plugin_auth_64513714 from 'nuxt_plugin_auth_64513714' // Source: .\\auth.js (mode: 'all')

// Component: <ClientOnly>
Vue.component(ClientOnly.name, ClientOnly)

// TODO: Remove in Nuxt 3: <NoSsr>
Vue.component(NoSsr.name, {
  ...NoSsr,
  render (h, ctx) {
    if (process.client && !NoSsr._warned) {
      NoSsr._warned = true

      console.warn('<no-ssr> has been deprecated and will be removed in Nuxt 3, please use <client-only> instead')
    }
    return NoSsr.render(h, ctx)
  }
})

// Component: <NuxtChild>
Vue.component(NuxtChild.name, NuxtChild)
Vue.component('NChild', NuxtChild)

// Component NuxtLink is imported in server.js or client.js

// Component: <Nuxt>
Vue.component(Nuxt.name, Nuxt)

Object.defineProperty(Vue.prototype, '$nuxt', {
  get() {
    const globalNuxt = this.$root.$options.$nuxt
    if (process.client && !globalNuxt && typeof window !== 'undefined') {
      return window.$nuxt
    }
    return globalNuxt
  },
  configurable: true
})

Vue.use(Meta, {"keyName":"head","attribute":"data-n-head","ssrAttribute":"data-n-head-ssr","tagIDKeyName":"hid"})

const defaultTransition = {"name":"page","mode":"out-in","appear":false,"appearClass":"appear","appearActiveClass":"appear-active","appearToClass":"appear-to"}

const originalRegisterModule = Vuex.Store.prototype.registerModule

function registerModule (path, rawModule, options = {}) {
  const preserveState = process.client && (
    Array.isArray(path)
      ? !!path.reduce((namespacedState, path) => namespacedState && namespacedState[path], this.state)
      : path in this.state
  )
  return originalRegisterModule.call(this, path, rawModule, { preserveState, ...options })
}

async function createApp(ssrContext, config = {}) {
  const router = await createRouter(ssrContext, config)

  const store = createStore(ssrContext)
  // Add this.$router into store actions/mutations
  store.$router = router

  // Fix SSR caveat https://github.com/nuxt/nuxt.js/issues/3757#issuecomment-414689141
  store.registerModule = registerModule

  // Create Root instance

  // here we inject the router and store to all child components,
  // making them available everywhere as `this.$router` and `this.$store`.
  const app = {
    head: {"title":"BIMBIM ID","meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0"},{"hid":"description","name":"description","content":"Belajar mudah bersama BimBim, Platform edukasi daerah No.1 di Trenggalek"},{"name":"theme-color","content":"#006d71"},{"name":"msapplication-TileImage","content":"\u002Flocig.png"},{"name":"msapplication-TileColor","content":"#006d71"}],"link":[{"rel":"icon","type":"image\u002Fx-icon","href":"\u002Flocig.png"},{"rel":"shortcut icon","href":"\u002Flocig.png"},{"rel":"preconnect","href":"https:\u002F\u002Ffonts.gstatic.com"},{"rel":"stylesheet","href":"https:\u002F\u002Funpkg.com\u002F@icon\u002Fthemify-icons\u002Fthemify-icons.css"},{"href":"https:\u002F\u002Ffonts.googleapis.com\u002Fcss2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap","rel":"stylesheet"}],"script":[{"hid":"tawk.to","src":"\u002Ftawk.js","defer":true}],"style":[]},

    store,
    router,
    nuxt: {
      defaultTransition,
      transitions: [defaultTransition],
      setTransitions (transitions) {
        if (!Array.isArray(transitions)) {
          transitions = [transitions]
        }
        transitions = transitions.map((transition) => {
          if (!transition) {
            transition = defaultTransition
          } else if (typeof transition === 'string') {
            transition = Object.assign({}, defaultTransition, { name: transition })
          } else {
            transition = Object.assign({}, defaultTransition, transition)
          }
          return transition
        })
        this.$options.nuxt.transitions = transitions
        return transitions
      },

      err: null,
      dateErr: null,
      error (err) {
        err = err || null
        app.context._errored = Boolean(err)
        err = err ? normalizeError(err) : null
        let nuxt = app.nuxt // to work with @vue/composition-api, see https://github.com/nuxt/nuxt.js/issues/6517#issuecomment-573280207
        if (this) {
          nuxt = this.nuxt || this.$options.nuxt
        }
        nuxt.dateErr = Date.now()
        nuxt.err = err
        // Used in src/server.js
        if (ssrContext) {
          ssrContext.nuxt.error = err
        }
        return err
      }
    },
    ...App
  }

  // Make app available into store via this.app
  store.app = app

  const next = ssrContext ? ssrContext.next : location => app.router.push(location)
  // Resolve route
  let route
  if (ssrContext) {
    route = router.resolve(ssrContext.url).route
  } else {
    const path = getLocation(router.options.base, router.options.mode)
    route = router.resolve(path).route
  }

  // Set context to app.context
  await setContext(app, {
    store,
    route,
    next,
    error: app.nuxt.error.bind(app),
    payload: ssrContext ? ssrContext.payload : undefined,
    req: ssrContext ? ssrContext.req : undefined,
    res: ssrContext ? ssrContext.res : undefined,
    beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : undefined,
    ssrContext
  })

  function inject(key, value) {
    if (!key) {
      throw new Error('inject(key, value) has no key provided')
    }
    if (value === undefined) {
      throw new Error(`inject('${key}', value) has no value provided`)
    }

    key = '$' + key
    // Add into app
    app[key] = value
    // Add into context
    if (!app.context[key]) {
      app.context[key] = value
    }

    // Add into store
    store[key] = app[key]

    // Check if plugin not already installed
    const installKey = '__nuxt_' + key + '_installed__'
    if (Vue[installKey]) {
      return
    }
    Vue[installKey] = true
    // Call Vue.use() to install the plugin into vm
    Vue.use(() => {
      if (!Object.prototype.hasOwnProperty.call(Vue.prototype, key)) {
        Object.defineProperty(Vue.prototype, key, {
          get () {
            return this.$root.$options[key]
          }
        })
      }
    })
  }

  // Inject runtime config as $config
  inject('config', config)

  if (process.client) {
    // Replace store state before plugins execution
    if (window.__NUXT__ && window.__NUXT__.state) {
      store.replaceState(window.__NUXT__.state)
    }
  }

  // Add enablePreview(previewData = {}) in context for plugins
  if (process.static && process.client) {
    app.context.enablePreview = function (previewData = {}) {
      app.previewData = Object.assign({}, previewData)
      inject('preview', previewData)
    }
  }
  // Plugin execution

  if (typeof nuxt_plugin_plugin_3a98660e === 'function') {
    await nuxt_plugin_plugin_3a98660e(app.context, inject)
  }

  if (typeof nuxt_plugin_templatesplugin8477430c_1e1c3d44 === 'function') {
    await nuxt_plugin_templatesplugin8477430c_1e1c3d44(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_toastclient_36975a0a === 'function') {
    await nuxt_plugin_toastclient_36975a0a(app.context, inject)
  }

  if (typeof nuxt_plugin_button_41332c0a === 'function') {
    await nuxt_plugin_button_41332c0a(app.context, inject)
  }

  if (typeof nuxt_plugin_helper_e3aabbe4 === 'function') {
    await nuxt_plugin_helper_e3aabbe4(app.context, inject)
  }

  if (typeof nuxt_plugin_icon_26efcaba === 'function') {
    await nuxt_plugin_icon_26efcaba(app.context, inject)
  }

  if (typeof nuxt_plugin_vlazyload_5cbc32ec === 'function') {
    await nuxt_plugin_vlazyload_5cbc32ec(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_clipboard_b96f3808 === 'function') {
    await nuxt_plugin_clipboard_b96f3808(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_pluginclient_2104092f === 'function') {
    await nuxt_plugin_pluginclient_2104092f(app.context, inject)
  }

  if (process.server && typeof nuxt_plugin_pluginserver_f2850a92 === 'function') {
    await nuxt_plugin_pluginserver_f2850a92(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_workbox_98792690 === 'function') {
    await nuxt_plugin_workbox_98792690(app.context, inject)
  }

  if (typeof nuxt_plugin_metaplugin_3db22938 === 'function') {
    await nuxt_plugin_metaplugin_3db22938(app.context, inject)
  }

  if (typeof nuxt_plugin_iconplugin_4259ceac === 'function') {
    await nuxt_plugin_iconplugin_4259ceac(app.context, inject)
  }

  if (typeof nuxt_plugin_axios_9b77a2c8 === 'function') {
    await nuxt_plugin_axios_9b77a2c8(app.context, inject)
  }

  if (typeof nuxt_plugin_vueslickcarousel_d8b69d56 === 'function') {
    await nuxt_plugin_vueslickcarousel_d8b69d56(app.context, inject)
  }

  if (typeof nuxt_plugin_veevalidate_81ef739a === 'function') {
    await nuxt_plugin_veevalidate_81ef739a(app.context, inject)
  }

  if (typeof nuxt_plugin_vueselect_d190152e === 'function') {
    await nuxt_plugin_vueselect_d190152e(app.context, inject)
  }

  if (typeof nuxt_plugin_vuejsmodal_9e1ca9ae === 'function') {
    await nuxt_plugin_vuejsmodal_9e1ca9ae(app.context, inject)
  }

  if (typeof nuxt_plugin_vuesocialsharing_504631e9 === 'function') {
    await nuxt_plugin_vuesocialsharing_504631e9(app.context, inject)
  }

  if (typeof nuxt_plugin_vueobservevisibility_c32a0d60 === 'function') {
    await nuxt_plugin_vueobservevisibility_c32a0d60(app.context, inject)
  }

  if (typeof nuxt_plugin_vuedatetimepicker_4d605153 === 'function') {
    await nuxt_plugin_vuedatetimepicker_4d605153(app.context, inject)
  }

  if (typeof nuxt_plugin_vueformwizard_9fcc0b72 === 'function') {
    await nuxt_plugin_vueformwizard_9fcc0b72(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_vueyoutubeembed_08ecc2a2 === 'function') {
    await nuxt_plugin_vueyoutubeembed_08ecc2a2(app.context, inject)
  }

  if (typeof nuxt_plugin_auth_64513714 === 'function') {
    await nuxt_plugin_auth_64513714(app.context, inject)
  }

  // Lock enablePreview in context
  if (process.static && process.client) {
    app.context.enablePreview = function () {
      console.warn('You cannot call enablePreview() outside a plugin.')
    }
  }

  // Wait for async component to be resolved first
  await new Promise((resolve, reject) => {
    router.push(app.context.route.fullPath, resolve, (err) => {
      // https://github.com/vuejs/vue-router/blob/v3.4.3/src/util/errors.js
      if (!err._isRouter) return reject(err)
      if (err.type !== 2 /* NavigationFailureType.redirected */) return resolve()

      // navigated to a different route in router guard
      const unregister = router.afterEach(async (to, from) => {
        if (process.server && ssrContext && ssrContext.url) {
          ssrContext.url = to.fullPath
        }
        app.context.route = await getRouteData(to)
        app.context.params = to.params || {}
        app.context.query = to.query || {}
        unregister()
        resolve()
      })
    })
  })

  return {
    store,
    app,
    router
  }
}

export { createApp, NuxtError }
