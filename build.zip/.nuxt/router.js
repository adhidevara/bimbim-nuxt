import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _a93abc56 = () => interopDefault(import('..\\pages\\bimguru\\index.vue' /* webpackChunkName: "pages/bimguru/index" */))
const _03a607c1 = () => interopDefault(import('..\\pages\\daftarMitra.vue' /* webpackChunkName: "pages/daftarMitra" */))
const _26475b40 = () => interopDefault(import('..\\pages\\editprofil.vue' /* webpackChunkName: "pages/editprofil" */))
const _79d36b6e = () => interopDefault(import('..\\pages\\kontak.vue' /* webpackChunkName: "pages/kontak" */))
const _55ce963f = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _3921665d = () => interopDefault(import('..\\pages\\mitra.vue' /* webpackChunkName: "pages/mitra" */))
const _fdc10584 = () => interopDefault(import('..\\pages\\privasi.vue' /* webpackChunkName: "pages/privasi" */))
const _37ae5347 = () => interopDefault(import('..\\pages\\produk.vue' /* webpackChunkName: "pages/produk" */))
const _e5e28c54 = () => interopDefault(import('..\\pages\\profil.vue' /* webpackChunkName: "pages/profil" */))
const _320f663d = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _9564066a = () => interopDefault(import('..\\pages\\tentangkami.vue' /* webpackChunkName: "pages/tentangkami" */))
const _3169157d = () => interopDefault(import('..\\pages\\bimguru\\_id.vue' /* webpackChunkName: "pages/bimguru/_id" */))
const _e7b219b0 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/bimguru",
    component: _a93abc56,
    name: "bimguru"
  }, {
    path: "/daftarMitra",
    component: _03a607c1,
    name: "daftarMitra"
  }, {
    path: "/editprofil",
    component: _26475b40,
    name: "editprofil"
  }, {
    path: "/kontak",
    component: _79d36b6e,
    name: "kontak"
  }, {
    path: "/login",
    component: _55ce963f,
    name: "login"
  }, {
    path: "/mitra",
    component: _3921665d,
    name: "mitra"
  }, {
    path: "/privasi",
    component: _fdc10584,
    name: "privasi"
  }, {
    path: "/produk",
    component: _37ae5347,
    name: "produk"
  }, {
    path: "/profil",
    component: _e5e28c54,
    name: "profil"
  }, {
    path: "/register",
    component: _320f663d,
    name: "register"
  }, {
    path: "/tentangkami",
    component: _9564066a,
    name: "tentangkami"
  }, {
    path: "/bimguru/:id",
    component: _3169157d,
    name: "bimguru-id"
  }, {
    path: "/",
    component: _e7b219b0,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
