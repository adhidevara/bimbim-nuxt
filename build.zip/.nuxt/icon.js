import Vue from 'vue'
import TvIcon from 'tv-icon'
import 'tv-icon/dist/tv-icon.css'
Vue.use(TvIcon)
